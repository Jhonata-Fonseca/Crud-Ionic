import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Aluno } from '../models/aluno';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-editar-aluno',
  templateUrl: './editar-aluno.page.html',
  styleUrls: ['./editar-aluno.page.scss'],
})
export class EditarAlunoPage implements OnInit {

  id: number;
  dados: Aluno;

  constructor(
    public activatedRoute: ActivatedRoute,
    public router: Router,
    public apiService: ApiService
  ) {
    this.dados = new Aluno();
  }

  ngOnInit() {
  this.id = this.activatedRoute.snapshot.params.id;
  this.apiService.getItem(this.id).subscribe((response)=>{
    this.dados= response;
  });
  }

  update(): void{
    this.apiService.updateItem(this.id, this.dados).subscribe((response)=>{
      this.router.navigate(['listar-aluno']);
    });
  }

}
