export class Aluno {
  id:number;
  nome:string;
  idade:number;
  email:string;
}
