import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, pipe } from 'rxjs';
import { retry, catchError } from "rxjs/operators";
import { Aluno } from '../models/aluno';
import { Http2ServerResponse } from 'http2';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  base_path = "http://localhost:3000/alunos";
  constructor(
    private http: HttpClient
  ) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type' : 'application/json'
    })
  };

  handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // Ocorreu um erro no cliente ou na rede.Manuseie de acordo.
      console.error('Ocorreu um erro:', error.error.message);
    } else {
      //O back-end retornou um código de resposta sem êxito.
      // O corpo da resposta pode conter dicas sobre o que deu errado,
      console.error(`Backend returned code ${error.status}, ` + `body was:${error.error}`);
    }
    // retornar um observable com uma mensagem de erro voltada para o usuário
    return throwError('Algo ruím aconteceu; por favor, tente novamente mais tarde..');
  }

  createItem(item):Observable<Aluno>{
    return this.http.post<Aluno>(this.base_path, JSON.stringify(item),this.httpOptions).pipe(retry(2),catchError(this.handleError));
  }
  
  getItem(id):Observable<Aluno>{
    return this.http.get<Aluno>(this.base_path +'/'+id).pipe(retry(2),catchError(this.handleError));
  }

  getList():Observable<Aluno>{
    return this.http.get<Aluno>(this.base_path).pipe(retry(2),catchError(this.handleError));
  }

  updateItem(id,item):Observable<Aluno>{
    return this.http.put<Aluno>(this.base_path +'/'+id, JSON.stringify(item),this.httpOptions).pipe(retry(2),catchError(this.handleError));
  }

  deleteItem(id){
    return this.http.delete<Aluno>(this.base_path +'/'+id,this.httpOptions).pipe(retry(2),catchError(this.handleError));
  }
}
