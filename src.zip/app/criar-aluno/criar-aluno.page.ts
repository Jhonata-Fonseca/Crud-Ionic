import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Aluno } from '../models/aluno';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { response } from 'express';

@Component({
  selector: 'app-criar-aluno',
  templateUrl: './criar-aluno.page.html',
  styleUrls: ['./criar-aluno.page.scss'],
})
export class CriarAlunoPage implements OnInit {

  dados: Aluno;
  constructor(
    private navCtrl: NavController,
    public apiService: ApiService,
    public router :Router
  ) {
    this.dados = new Aluno();
   }

  submitForm():void{
    this.apiService.createItem(this.dados).subscribe(
      (response)=>{
        this.router.navigate(['listar-aluno'])
      }
    );
  }

  ngOnInit() {
  }

  abrirPagina(nomeDaPagina:string):void{
    this.navCtrl.navigateForward(nomeDaPagina);
  }
}
