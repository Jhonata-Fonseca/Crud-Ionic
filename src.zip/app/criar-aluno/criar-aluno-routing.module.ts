import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CriarAlunoPage } from './criar-aluno.page';

const routes: Routes = [
  {
    path: '',
    component: CriarAlunoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CriarAlunoPageRoutingModule {}
