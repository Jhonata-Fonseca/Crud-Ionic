import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CriarAlunoPageRoutingModule } from './criar-aluno-routing.module';

import { CriarAlunoPage } from './criar-aluno.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CriarAlunoPageRoutingModule
  ],
  declarations: [CriarAlunoPage]
})
export class CriarAlunoPageModule {}
