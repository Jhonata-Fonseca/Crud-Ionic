import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { runInThisContext } from 'vm';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-listar-aluno',
  templateUrl: './listar-aluno.page.html',
  styleUrls: ['./listar-aluno.page.scss'],
})
export class ListarAlunoPage implements OnInit {

  dadosAlunos: any;

  constructor(
    public apiService: ApiService,
    private navCtrl: NavController
  ) {
    this.dadosAlunos = [];
  }
  ionViewWillEnter() {
    this.getTodosAlunos();
  }
  getTodosAlunos(): void{
    this.apiService.getList().subscribe((response)=>{
      console.log(response);
      this.dadosAlunos = response;
    });
  }

  ngOnInit() {
  }

  abrirPagina(nomeDaPagina: string): void{
    this.navCtrl.navigateForward(nomeDaPagina);
  }

  delete(item): void{
    this.apiService.deleteItem(item.id).subscribe((response)=>{
      this.getTodosAlunos();
    });
  }
}
